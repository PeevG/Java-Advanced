public class Engine {

    private int engineSpeed;
    private int enginePower;

    public Engine(int enginePower, int engineSpeed) {
        this.engineSpeed = engineSpeed;
        this.enginePower = enginePower;
    }

    public int getEnginePower() {
        return enginePower;
    }

}
