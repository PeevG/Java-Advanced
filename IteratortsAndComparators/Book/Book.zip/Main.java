

public class Main {
    public static void main(String[] args) {
        Book book1 = new Book("The book", 1450);
        Book book2 = new Book("The book2", 1921, "Carl Sagan", "Ann Druyan");

    }
}
